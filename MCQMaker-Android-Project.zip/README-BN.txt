MCQ Maker Android APK project

এই ZIP হলো Android Studio/GitHub Actions দিয়ে APK বানানোর প্রজেক্ট; এখানে তৈরি APK সরাসরি অন্তর্ভুক্ত নয়।

সহজ পদ্ধতি:
1. ZIP extract করুন।
2. GitHub-এ একটি নতুন repository তৈরি করে এই ফোল্ডারের সব ফাইল upload করুন।
3. Actions tab খুলুন।
4. "Build MCQ Maker APK" workflow নির্বাচন করে Run workflow চাপুন।
5. কাজ শেষ হলে workflow run-এর Artifacts থেকে MCQ-Maker-APK ডাউনলোড করুন।
6. ZIP artifact extract করে app-debug.apk ফোনে install করুন। Android-এ unknown apps install করার অনুমতি দিতে হতে পারে।

Android Studio পদ্ধতি:
1. Android Studio-তে এই ফোল্ডার Open করুন।
2. Gradle sync শেষ হতে দিন।
3. Build > Build APK(s) নির্বাচন করুন।
4. APK সাধারণত app/build/outputs/apk/debug/app-debug.apk-এ থাকবে।

নোট:
- AI দিয়ে প্রশ্ন তৈরি করতে অ্যাপের ভিতরে Gemini API key দিতে হবে।
- PDF/ছবি নির্বাচন করার জন্য Android file picker যুক্ত আছে।
- এটি debug APK; Play Store release-এর জন্য আলাদা signing দরকার।
